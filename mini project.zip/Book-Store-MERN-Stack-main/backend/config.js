export const PORT = 5555;

export const mongoDBURL = "mongodb://127.0.0.1:27017/book-store";

export const JWT_SECRET = "your_jwt_secret_key";
// Please create a free database for yourself.
// This database will be deleted after tutorial
